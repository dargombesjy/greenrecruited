import{l as o,a as r}from"../chunks/izS0NcGz.js";export{o as load_css,r as start};
