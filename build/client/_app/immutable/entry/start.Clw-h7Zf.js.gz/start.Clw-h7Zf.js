import{l as o,a as r}from"../chunks/JSRjBsIX.js";export{o as load_css,r as start};
