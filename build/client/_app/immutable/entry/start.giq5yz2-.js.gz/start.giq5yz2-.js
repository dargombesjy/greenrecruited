import{l as o,a as r}from"../chunks/5Mpu2QtM.js";export{o as load_css,r as start};
