import{l as o,a as r}from"../chunks/CEAD515h.js";export{o as load_css,r as start};
