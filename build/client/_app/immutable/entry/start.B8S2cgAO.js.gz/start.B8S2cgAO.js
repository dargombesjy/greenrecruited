import{l as o,a as r}from"../chunks/CpMiaJEv.js";export{o as load_css,r as start};
